export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      events: {
        Row: {
          id: string
          name: string
          description: string | null
          location: string
          date: string
          created_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          location: string
          date: string
          created_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          location?: string
          date?: string
          created_by?: string
          created_at?: string
          updated_at?: string
        }
      }
      attendees: {
        Row: {
          id: string
          name: string
          email: string
          created_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          created_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          created_by?: string
          created_at?: string
          updated_at?: string
        }
      }
      event_attendees: {
        Row: {
          id: string
          event_id: string
          attendee_id: string
          created_at: string
        }
        Insert: {
          id?: string
          event_id: string
          attendee_id: string
          created_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          attendee_id?: string
          created_at?: string
        }
      }
      tasks: {
        Row: {
          id: string
          name: string
          description: string | null
          deadline: string
          status: 'pending' | 'completed'
          event_id: string
          assignee_id: string | null
          created_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          deadline: string
          status: 'pending' | 'completed'
          event_id: string
          assignee_id?: string | null
          created_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          deadline?: string
          status?: 'pending' | 'completed'
          event_id?: string
          assignee_id?: string | null
          created_by?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}