import { Link, useLocation } from 'react-router-dom';
import { Calendar, Users, CheckSquare, LogOut } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import clsx from 'clsx';

const navigation = [
  { name: 'Events', to: '/', icon: Calendar },
  { name: 'Attendees', to: '/attendees', icon: Users },
  { name: 'Tasks', to: '/tasks', icon: CheckSquare },
];

export function Sidebar() {
  const location = useLocation();

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="flex flex-col w-64 bg-white border-r">
      <div className="flex items-center justify-center h-16 border-b">
        <h1 className="text-xl font-bold text-gray-900">Event Dashboard</h1>
      </div>
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.name}>
                <Link
                  to={item.to}
                  className={clsx(
                    'flex items-center px-4 py-2 text-sm font-medium rounded-md',
                    location.pathname === item.to
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-50'
                  )}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="p-4 border-t">
        <button
          onClick={handleLogout}
          className="flex items-center w-full px-4 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Sign out
        </button>
      </div>
    </div>
  );
}